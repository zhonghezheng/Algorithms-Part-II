
import edu.princeton.cs.algs4.Picture;

import java.io.File;

public class SeamCarver
{
    private Picture picture;
    private double[][] Energy ;

    // create a seam carver object based on the given picture
    public SeamCarver(Picture picture)
    {
        if (picture == null)
        {
            throw  new IllegalArgumentException();
        }

        this.picture = new Picture(picture);

        SetEnergy(this.picture);

    }

    private void SetEnergy (Picture picture)
    {
        Energy = new double[picture.height()][picture.width()];

        for (int i=0; i<picture.height(); i++)
        {
            for (int j=0; j<picture.width(); j++)
            {
                if (i==0||i==picture.height()-1||j==0||j==picture.width()-1)
                {
                    Energy[i][j] = 1000.00;
                }

                else
                {
                    double xRedchange = Math.pow(picture.get(j,i-1).getRed()-picture.get(j,i+1).getRed(),2);
                    double xBluechange = Math.pow(picture.get(j,i-1).getBlue()-picture.get(j,i+1).getBlue(),2);
                    double xGreenchange = Math.pow(picture.get(j,i-1).getGreen()-picture.get(j,i+1).getGreen(),2);
                    double xchange = xRedchange + xBluechange + xGreenchange;

                    double yRedchange = Math.pow(picture.get(j-1,i).getRed()-picture.get(j+1,i).getRed(),2);
                    double yBluechange = Math.pow(picture.get(j-1,i).getBlue()-picture.get(j+1,i).getBlue(),2);
                    double yGreenchange = Math.pow(picture.get(j-1,i).getGreen()-picture.get(j+1,i).getGreen(),2);
                    double ychange = yRedchange + yBluechange + yGreenchange;

                    Energy[i][j] = Math.sqrt(xchange + ychange);
                }
            }
        }
    }

    // current picture
    public Picture picture()
    {
        return picture;
    }

    // width of current picture
    public int width()
    {
        return picture.width();
    }


    // height of current picture
    public int height()
    {
        return picture.height();
    }

    // energy of pixel at column x and row y
    public double energy(int x, int y)
    {
        if (x>=picture.width()||y>=picture.height()||x<0||y<0)
        {
            throw new IllegalArgumentException();
        }

        return Energy [y][x];
    }


    // sequence of indices for horizontal seam
    public int[] findHorizontalSeam()
    {
        double minBottomEnergy = Integer.MAX_VALUE;
        int [] Path = new int [picture.width()];
        int[][] ParentTo = new int[picture.height()][picture.width()];
        double [][] minEnergy = new double[picture.height()][picture.width()];

        for (int j=0; j<picture.width(); j++)
        {
            for (int i =0; i<picture.height(); i++)
            {
                double EnergyShortestToPixel = Integer.MAX_VALUE;

                if (j==0)
                {
                    minEnergy[i][j] = 1000.00;
                    ParentTo[i][j] = i;
                }

                else
                {
                    if (i!=0 && minEnergy[i-1][j-1]<EnergyShortestToPixel)
                    {
                        EnergyShortestToPixel = minEnergy[i-1][j-1];
                        ParentTo [i][j] = i-1;
                        minEnergy[i][j] = minEnergy[i-1][j-1] + Energy[i][j];
                    }

                    if (i!=picture.height()-1 &&minEnergy[i+1][j-1]<EnergyShortestToPixel)
                    {
                        EnergyShortestToPixel = minEnergy[i+1][j-1];
                        ParentTo [i][j] = i+1;
                        minEnergy[i][j] = minEnergy[i+1][j-1] + Energy[i][j];
                    }

                    if (minEnergy[i][j-1]<EnergyShortestToPixel)
                    {
                        EnergyShortestToPixel = minEnergy[i][j-1];
                        ParentTo [i][j] = i;
                        minEnergy[i][j] = minEnergy[i][j-1] + Energy[i][j];
                    }
                }
            }
        }

        int Index = 0;

        for (int i=0; i<picture.height(); i++)
        {
            if (minEnergy[i][picture.width()-1]<minBottomEnergy)
            {
                minBottomEnergy = minEnergy[i][picture.width()-1];
                Index = i;
            }
        }

        for (int j=picture.width()-1; j>=0; j--)
        {
            Path[j] = Index;
            Index = ParentTo[Index][j];
        }

        return Path;
    }


    // sequence of indices for vertical seam
    public int[] findVerticalSeam()
    {
        double minBottomEnergy = Integer.MAX_VALUE;
        int [] Path = new int [picture.height()];
        int[][] ParentTo = new int[picture.height()][picture.width()];
        double [][] minEnergy = new double[picture.height()][picture.width()];

        for (int i=0; i<picture.height(); i++)
        {
            for (int j =0; j<picture.width(); j++)
            {
                double EnergyShortestToPixel = Integer.MAX_VALUE;

                if (i==0)
                {
                    minEnergy[i][j] = 1000.00;
                    ParentTo[i][j] = j;
                }

                else
                {
                    if (j!=0 && minEnergy[i-1][j-1]<EnergyShortestToPixel)
                    {
                        EnergyShortestToPixel = minEnergy[i-1][j-1];
                        ParentTo [i][j] = j-1;
                        minEnergy[i][j] = minEnergy[i-1][j-1] + Energy[i][j];
                    }

                    if (j!=picture.width()-1 &&minEnergy[i-1][j+1]<EnergyShortestToPixel)
                    {
                        EnergyShortestToPixel = minEnergy[i-1][j+1];
                        ParentTo [i][j] = j+1;
                        minEnergy[i][j] = minEnergy[i-1][j+1] + Energy[i][j];
                    }

                    if (minEnergy[i-1][j]<EnergyShortestToPixel)
                    {
                        EnergyShortestToPixel = minEnergy[i-1][j];
                        ParentTo [i][j] = j;
                        minEnergy[i][j] = minEnergy[i-1][j] + Energy[i][j];
                    }
                }
            }
        }

        int Index = 0;

        for (int j=0; j<picture.width(); j++)
        {
            if (minEnergy[picture.height()-1][j]<minBottomEnergy)
            {
                minBottomEnergy = minEnergy[picture.height()-1][j];
                Index = j;
            }
        }

        for (int i=picture.height()-1; i>=0; i--)
        {
            Path[i] = Index;
            Index = ParentTo[i][Index];
        }

        return Path;

    }

    // remove horizontal seam from current picture
    public void removeHorizontalSeam(int[] seam)
    {
        if (seam == null || picture.height() <= 1 || seam.length != picture.width())
        {
            throw new IllegalArgumentException();
        }


        Picture shifted = new Picture(picture.width(), picture.height()-1);

        int y = 0;

        for (int i=0; i<seam.length; i++)
        {
            if (seam[i]<0||seam[i]>=picture.height())
            {
                throw new IllegalArgumentException();
            }

            if (i>0 && Math.abs(seam[i-1] - seam[i])>1)
            {
                throw new IllegalArgumentException();
            }

            for (int x=0; x<picture.height()-1; x++)
            {
                if (x>=seam[i])
                {
                    shifted.set(y, x,picture.get(y,x+1));
                }
                else
                {
                    shifted.set(y, x, picture.get(y, x));
                }
            }

            y+=1;
        }

        SetEnergy(shifted);
        picture = shifted;
    }

    // remove vertical seam from current picture
    public void removeVerticalSeam(int[] seam)
    {
        if (seam == null||picture.width()<=1 || seam.length != picture.height())
        {
            throw new IllegalArgumentException();
        }

        Picture shifted = new Picture(picture.width()-1, picture.height());
        int x = 0;

        for (int j=0; j<seam.length;j++)
        {
            if (seam[j]<0||seam[j]>=picture.width())
            {
                throw new IllegalArgumentException();
            }

            if (j>0 && Math.abs(seam[j-1] - seam[j])>1)
            {
                throw new IllegalArgumentException();
            }

            for (int y=0; y<picture.width()-1; y++)
            {
                if (y>=seam[j])
                {
                    shifted.set(y,x,picture.get(y+1,x));
                }
                else
                {
                    shifted.set(y, x, picture.get(y, x));
                }
            }

            x+=1;
        }

        SetEnergy(shifted);
        picture = shifted;
    }

    //  unit testing (optional)
    public static void main(String[] args)
    {
        File picSource = new File("12x10.png");
        SeamCarver pic = new SeamCarver(new Picture(picSource));
        pic.energy(0,0);

        for (double[] e: pic.Energy)
        {
            for (Double a : e)
            {
                 System.out.println(a);
            }
        }

        for (int e:pic.findVerticalSeam())
        {
           System.out.println(e);
        }

        pic.removeHorizontalSeam(pic.findHorizontalSeam());

    }

}