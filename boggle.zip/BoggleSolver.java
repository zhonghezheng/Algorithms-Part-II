import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

import java.util.HashSet;

public class BoggleSolver
{
    private HashSet<String> ValidWords;
    private HashSet<String > DictionarySub;
    private HashSet<String > Dictionary;
    private boolean containsQ;

    public BoggleSolver(String[] dictionary)
    {
        Dictionary = new HashSet<>();
        DictionarySub = new HashSet<>();

        for (int i = dictionary.length-1; i >=0; i--)
        {
            for (int j=1; j<dictionary[i].length(); j++)
                DictionarySub.add(dictionary[i].substring(0,j));

            Dictionary.add(dictionary[i]);
            DictionarySub.add(dictionary[i]);
        }
    }

    // Returns the set of all valid words in the given Boggle board, as an Iterable.
    public Iterable<String> getAllValidWords(BoggleBoard board)
    {
        ValidWords = new HashSet<>();

        for (int i=0; i<board.rows(); i++)
        {
            for (int j=0; j<board.cols(); j++)
            {
                PossibleWords(board, i, j, "", new boolean[board.rows()][board.cols()]);
            }
        }

        return ValidWords;
    }


    // Returns the score of the given word if it is in the dictionary, zero otherwise.
    // (You can assume the word contains only the uppercase letters A through Z.)
    public int scoreOf(String word)
    {
        if (!Dictionary.contains(word))
            return 0;

            if (word.length() == 3 || word.length() == 4)
                return 1;

            else if (word.length() == 5)
                return 2;

            else if (word.length() == 6)
                return 3;

            else if (word.length() == 7)
                return 5;

            return 11;
    }

    private void PossibleWords (BoggleBoard board, int i, int j, String word, boolean[][] visited)
    {
        if (!visited[i][j]) {
            visited[i][j] = true;

            word += board.getLetter(i, j);

            if (board.getLetter(i, j) == 'Q') {
                word += "U";
            }

            if (word.length() >= 3 && Dictionary.contains(word)) {
                ValidWords.add(word);
            }

            if (DictionarySub.contains(word)) {
                if (i != 0) {

                    if (!visited[i - 1][j])
                        PossibleWords(board, i - 1, j, word, visited);

                    if (j != 0 && !visited[i - 1][j - 1]) {
                        PossibleWords(board, i - 1, j - 1, word, visited);
                    }

                    if (j != board.cols() - 1 && !visited[i - 1][j + 1]) {
                        PossibleWords(board, i - 1, j + 1, word, visited);
                    }
                }

                if (j != 0 && !visited[i][j - 1]) {
                    PossibleWords(board, i, j - 1, word, visited);
                }


                if (j != board.cols() - 1 && !visited[i][j + 1]) {
                    PossibleWords(board, i, j + 1, word, visited);
                }

                if (i != board.rows() - 1) {
                    if (!visited[i + 1][j])
                        PossibleWords(board, i + 1, j, word, visited);

                    if (j != 0 && !visited[i + 1][j - 1]) {
                        PossibleWords(board, i + 1, j - 1, word, visited);
                    }

                    if (j != board.cols() - 1 && !visited[i + 1][j + 1])
                    {
                        PossibleWords(board, i + 1, j + 1, word, visited);
                    }
                }
            }
        }

        visited[i][j] = false;
    }
    public static void main(String[] args) {
        In in = new In("dictionary-yawl.txt");
        String[] dictionary = in.readAllStrings();
        BoggleSolver solver = new BoggleSolver(dictionary);
        BoggleBoard board = new BoggleBoard("board-points26539.txt");
        int score = 0;
        for (String word : solver.getAllValidWords(board)) {
            StdOut.println(word);
            score += solver.scoreOf(word);
        }
        StdOut.println("Score = " + score);
    }
}
