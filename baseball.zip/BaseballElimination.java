import edu.princeton.cs.algs4.FlowEdge;
import edu.princeton.cs.algs4.FlowNetwork;
import edu.princeton.cs.algs4.FordFulkerson;
import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdOut;

import java.util.HashMap;
import java.util.HashSet;

public class BaseballElimination
{
    private class Team
    {
        int ID, Won, Lost, GamesLeft;
        String Name;

        public Team (int ID, String n, int W, int L, int GLeft)
        {
            this.ID = ID;
            Name = n;
            Won = W;
            Lost = L;
            GamesLeft = GLeft;
        }
    }

    private class Match
    {
        int team1, team2;
        int GamesBetweenTeams;
        public Match (int ID1, int ID2, int GBT)
        {
            team1 = ID1;
            team2 = ID2;
            GamesBetweenTeams = GBT;
        }
    }

    private HashMap<Integer, Match> MatchIDs;
    private HashMap<Integer, Team> TeamIDs;
    private HashMap<String, Integer> NameToID;
    private int [][] GameIDs;
    private int VTotal;
    private FordFulkerson Matches;

    // create a baseball division from given filename in format specified below
    public BaseballElimination(String filename)
    {
        In in = new In(filename);
        int NumOfTeams = in.readInt();

        MatchIDs = new HashMap<>();
        TeamIDs = new HashMap<>();
        NameToID = new HashMap<>();
        GameIDs = new int[NumOfTeams][NumOfTeams];
        int MatchIDCounter = NumOfTeams;

        for (int i=0; i<NumOfTeams; i++)
        {
            int teamID = i;
            String Name = in.readString();
            int Wins = in.readInt();
            int Losses = in.readInt();
            int GamesLeft = in.readInt();
            TeamIDs.put(teamID, new Team(teamID, Name, Wins, Losses, GamesLeft));
            NameToID.put(Name, teamID);

            for (int j=0; j<NumOfTeams; j++) {
                if (j <= i) {
                    in.readInt();
                }
                else {
                    MatchIDs.put(MatchIDCounter, new Match(teamID, j, in.readInt()));
                    GameIDs[i][j] = MatchIDCounter;
                    GameIDs[j][i] = MatchIDCounter;
                    MatchIDCounter +=1;
                }
            }
        }

        VTotal = MatchIDCounter+1;
    }

    // number of teams
    public int numberOfTeams()
    {
        return TeamIDs.size();
    }

    // all teams
    public Iterable<String> teams()
    {
        return NameToID.keySet();
    }

    // number of wins for given team
    public int wins(String team)
    {
        if (!NameToID.containsKey(team))
        {
            throw new IllegalArgumentException();
        }
        return TeamIDs.get(NameToID.get(team)).Won;
    }

    // number of losses for given team
    public int losses(String team)
    {
        if (!NameToID.containsKey(team))
        {
            throw new IllegalArgumentException();
        }
        return TeamIDs.get(NameToID.get(team)).Lost;
    }

    // number of remaining games for given team
    public int remaining(String team)
    {
        if (!NameToID.containsKey(team))
        {
            throw new IllegalArgumentException();
        }
        return TeamIDs.get(NameToID.get(team)).GamesLeft;

    }

    // number of remaining games between team1 and team2
    public int against(String team1, String team2)
    {
        if (!NameToID.containsKey(team1)||!NameToID.containsKey(team2))
        {
            throw new IllegalArgumentException();
        }
        int Team1ID = NameToID.get(team1);
        int Team2ID = NameToID.get(team2);
        int GameID = GameIDs[Team1ID][Team2ID];
        return MatchIDs.get(GameID).GamesBetweenTeams;
    }

    // is given team eliminated?
    public boolean isEliminated(String team)
    {
        if (!NameToID.containsKey(team))
        {
            throw new IllegalArgumentException();
        }

        int TeamID = NameToID.get(team);
        int MaxWin = TeamIDs.get(TeamID).Won + TeamIDs.get(TeamID).GamesLeft;

        if (!TrivialElimination(MaxWin).isEmpty())
        {
            return true;
        }

        FlowNetwork G = new FlowNetwork(VTotal);

        for (int i = 0; i < numberOfTeams() - 1; i++)
        {
            for (int j = i + 1; j < numberOfTeams(); j++)
            {
                if (i != TeamID && j != TeamID)
                {
                    //Sorce to Match (Souce, MatachID, Capacity = Games left between team i and team j)
                    G.addEdge(new FlowEdge(VTotal - 1, GameIDs[i][j],
                                           against(TeamIDs.get(i).Name, TeamIDs.get(j).Name)));

                    //Match to each team
                    G.addEdge(new FlowEdge(GameIDs[i][j], i, Double.POSITIVE_INFINITY));
                    G.addEdge(new FlowEdge(GameIDs[i][j], j, Double.POSITIVE_INFINITY));
                }
            }
        }

        //team to target
        for (int i = 0; i < numberOfTeams(); i++) {
            if (i != TeamID) {
                G.addEdge(new FlowEdge(i, TeamID, MaxWin - TeamIDs.get(i).Won));
            }
        }

        Matches = new FordFulkerson(G, VTotal - 1, TeamID);

        for (FlowEdge e : G.adj(VTotal - 1))
        {
            if (e.flow()!=e.capacity())
            {
                return true;
            }
        }

        return false;
    }

    // subset R of teams that eliminates given team; null if not eliminated
    public Iterable<String> certificateOfElimination(String team)
    {
        if (!NameToID.containsKey(team))
        {
            throw new IllegalArgumentException();
        }

        int TeamID = NameToID.get(team);
        int MaxWin = TeamIDs.get(TeamID).Won + TeamIDs.get(TeamID).GamesLeft;
        HashSet<String> R = TrivialElimination(MaxWin);

        if (!R.isEmpty())
        {
            return R;
        }

        if (isEliminated(team))
        {
            R = new HashSet<>();

            for (int i = 0; i < numberOfTeams() - 1; i++)
            {
                for (int j = i + 1; j < numberOfTeams(); j++)
                {
                    if (i != TeamID && j != TeamID)
                    {
                        if (Matches.inCut((GameIDs[i][j])))
                        {
                            R.add(TeamIDs.get(MatchIDs.get(GameIDs[i][j]).team1).Name);
                            R.add(TeamIDs.get(MatchIDs.get(GameIDs[i][j]).team2).Name);
                        }
                    }
                }
            }

            return R;
        }

        return null;
    }

    private HashSet<String> TrivialElimination (int MaxWins)
    {
        HashSet<String> R = new HashSet<>();
        for (Team e: TeamIDs.values())
        {
            if (MaxWins < e.Won)
            {
                R.add(e.Name);
            }
        }

        return R;
    }
    public static void main(String[] args) {
        BaseballElimination division = new BaseballElimination(args[0]);
        for (String team : division.teams()) {
            if (division.isEliminated(team)) {
                StdOut.print(team + " is eliminated by the subset R = { ");
                for (String t : division.certificateOfElimination(team)) {
                    StdOut.print(t + " ");
                }
                StdOut.println("}");
            }
            else {
                StdOut.println(team + " is not eliminated");
            }
        }
    }
}
